#!/usr/bin/env sh
# surface-dtx detachment handler
